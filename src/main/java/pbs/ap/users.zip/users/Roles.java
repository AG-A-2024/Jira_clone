package pbs.ap.users;

public enum Roles {
    ADMIN, USER
}
